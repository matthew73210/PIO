# Community participation
The first entry step for participating to OMG is sharing and discussing with the [community](https://community.openmqttgateway.com), by sharing your experiences and answering to other questions you are giving back what the others gave to you.

You can use the forum to ask questions, post answers, suggest features and discuss about home automation or Internet of things in a more general way. 